##Note for Assignment Answers
1. The solution for `Question 2` and `Question3` is done in the
files with respective folder name as `Q2` and `Q3` respectively.

2. For answers to `Q3`, please run `SetTimeout.html` file. The 
texts with **Green** color are the answers.

##Thank You!

